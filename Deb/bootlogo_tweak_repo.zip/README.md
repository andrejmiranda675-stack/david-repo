# Bootlogo tweak repo zip

Upload the `repo/` folder contents to GitHub Pages.
The `source/BootlogoChanger/` folder is the tweak scaffold.
