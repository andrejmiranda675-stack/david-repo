Bootlogo Changer tweak scaffold.
This is a template package, not a finished bootlogo changer.
