# BootlogoChanger

Cydia tweak scaffold with Theos-style source and a matching repo package.
