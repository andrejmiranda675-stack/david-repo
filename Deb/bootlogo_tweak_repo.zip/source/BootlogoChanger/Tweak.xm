#import <UIKit/UIKit.h>

%ctor {
    NSLog(@"[BootlogoChanger] loaded");
}
