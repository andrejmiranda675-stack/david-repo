Bootlogo Changer theme package.

This package is a theme-style skeleton for GitHub repo hosting.
